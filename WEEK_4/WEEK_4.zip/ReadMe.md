# Week 4 Assignment

These are part of some exercises **(Exercise 1 to Exercise 7)** from the merged **Week 4 & 5 Assignment**, while the remaining exercises **(Exercise 8 to Exercise 15)** are located in the **Week 5 assignment folder**.
