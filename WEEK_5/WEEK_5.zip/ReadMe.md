# Week 5 Assignment

These are the remaining exercises **(Exercise 8 to Exercise 15)** from the merged **Week 4 & 5 Assignment**, while the previous remaining exercises **(Exercise 1 to Exercise 7)** are located in the **Week 4 assignment folder**.
